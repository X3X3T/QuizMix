plugins {
    id("com.android.application")
}

android {
    namespace = "com.quizmix.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.quizmix.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.4"
    }

    signingConfigs {
        create("stableDebug") {
            storeFile = file("quizmix-debug.keystore")
            storePassword = "quizmix-dev-only"
            keyAlias = "quizmixdebug"
            keyPassword = "quizmix-dev-only"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDebug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
