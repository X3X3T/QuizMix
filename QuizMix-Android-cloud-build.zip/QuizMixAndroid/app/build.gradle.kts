plugins {
    id("com.android.application")
}

android {
    namespace = "com.quizmix.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.quizmix.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.2"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
