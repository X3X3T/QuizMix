(() => {
  'use strict';
  const BANK = Array.isArray(window.QUIZMIX_BANK) ? window.QUIZMIX_BANK : [];
  const SUBJECTS = {
    chem: {name:'Химия', short:'Химия', icon:'⚗', cls:'chem-tag', color:'#c6a2ff'},
    bio: {name:'Биология', short:'Биология', icon:'✳', cls:'bio-tag', color:'#7fe0b3'},
    rus: {name:'Русский язык', short:'Русский', icon:'Аа', cls:'rus-tag', color:'#ffd27a'},
    pdd: {name:'ПДД', short:'ПДД', icon:'▰', cls:'pdd-tag', color:'#86baff'}
  };
  const STORAGE_KEY = 'quizmix_progress_v2';
  const THEME_KEY = 'quizmix_theme_v1';
  const HOLIDAY_KEY = 'quizmix_holidays_v1';
  const $ = (id) => document.getElementById(id);
  let selectedCount = 25;
  let selectedSubjects = new Set(Object.keys(SUBJECTS));
  let session = null;
  let reviewSource = null;
  let reviewReturnScreen = 'home-screen';
  let reviewFilter = 'all';
  let holidaysMode = false;

  const RUS_HINTS = {
    'rus-001':'Проверь значение приставки: приближение, присоединение, близость или неполнота действия.',
    'rus-002':'Сопоставь слова-маркеры времени «ежедневно», «вчера», «завтра» с формой глагола.',
    'rus-003':'Вспомни исключения из правила Н/НН в прилагательных.',
    'rus-004':'Вспомни словарное написание слова и проверь количество согласных в корне.',
    'rus-005':'Проверь, употребляется ли глагол без НЕ и есть ли противопоставление.',
    'rus-006':'Это глагол, который без НЕ в современном русском языке не употребляется.',
    'rus-007':'Вспомни правило О/Ё после шипящих в корне и слова-исключения.',
    'rus-008':'Отличи наречие со значением «позже» от существительного с предлогом.',
    'rus-009':'Задай к глаголу вопрос «что делать?» и проверь инфинитив.',
    'rus-010':'Задай вопрос «что делает?». Форма 3-го лица настоящего времени пишется иначе, чем инфинитив.',
    'rus-011':'Подбери проверочное однокоренное слово «праздный», в котором согласный слышен отчётливо.',
    'rus-012':'Это словарное слово: проверь написание по орфографической норме.',
    'rus-013':'Выбор С/З в приставке зависит от следующего согласного; перед глухим согласным пишется С.',
    'rus-014':'Определи, с какого согласного начинается корень, и примени правило приставок на З/С.',
    'rus-015':'После «пол-» дефис обычно ставится перед гласной, заглавной буквой и Л.',
    'rus-016':'Вводные слова выражают отношение говорящего и обычно выделяются парными запятыми.',
    'rus-017':'Найди грамматические основы по обе стороны союза и проверь, сложное ли это предложение.',
    'rus-018':'Проверь, соединяет ли союз однородные члены или части сложного предложения.',
    'rus-019':'Найди обобщающее слово и перечисление, которое за ним следует.',
    'rus-020':'Вводное слово можно убрать без разрушения грамматической основы предложения.',
    'rus-021':'Сравни одиночный соединительный союз между однородными членами и союз между частями сложного предложения.',
    'rus-022':'Учитывай цель высказывания и интонацию побуждения.',
    'rus-023':'Посмотри, какую синтаксическую роль выполняет слово и что оно обозначает.',
    'rus-024':'Проверь, обозначает ли слово признак предмета и с чем оно согласуется.',
    'rus-025':'Наречие обычно обозначает признак действия или другого признака.',
    'rus-026':'Задай к слову вопрос от глагола: «делает как?»',
    'rus-027':'Эта часть речи служит для связи слов и не изменяется.',
    'rus-028':'Вспомни падежные вопросы и сопоставь их с управлением слова.',
    'rus-029':'Вспомни вопросы косвенных падежей и значение адресата действия.',
    'rus-030':'Найди главный член, который называет предмет речи и отвечает на вопрос «кто? что?»',
    'rus-031':'Найди член грамматической основы, который сообщает о подлежащем.',
    'rus-032':'Сопоставь значения слов: здесь важна противоположность, а не близость звучания.',
    'rus-033':'Нужны слова с близким, но не обязательно полностью одинаковым значением.',
    'rus-034':'Учитывай совпадение формы при различии лексических значений.',
    'rus-035':'Вспомни значение устойчивого выражения, а не буквальный смысл его слов.',
    'rus-036':'Не путай слова «невежда» и «невежа»: они обозначают разные недостатки.',
    'rus-037':'Сосчитай все буквы, включая Ъ, Ь и Ё.',
    'rus-038':'Раздели буквы, которые обозначают звуки, и знаки, выполняющие только разделительную или смягчающую функцию.',
    'rus-039':'Считай именно гласные буквы, а не гласные звуки.',
    'rus-040':'Вспомни сонорные согласные и их акустические свойства.',
    'rus-041':'Эта морфема находится перед корнем и участвует в образовании новых слов.',
    'rus-042':'Измени форму слова и найди изменяемую часть, которая связывает слова в словосочетании.',
    'rus-043':'Подбери несколько родственных слов и найди общую значимую часть.',
    'rus-044':'Посчитай грамматические основы, а не количество сказуемых само по себе.',
    'rus-045':'Посмотри, есть ли между частями сочинительные или подчинительные союзы.',
    'rus-046':'Определи, на какой вопрос отвечает придаточная часть и к чему она относится.',
    'rus-047':'Обрати внимание на точность терминов, логичность и доказательность изложения.',
    'rus-048':'Вспомни стиль, характерный для документов и официальных отношений.',
    'rus-049':'Для начальной формы нужно привести существительное к словарной форме.',
    'rus-050':'Определи, указывает ли местоимение на участника речевой ситуации.',
    'rus-051':'Это неизменяемая начальная форма глагола.'
  };

  function safeRead() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('quizmix_progress_v1') || '{}';
      const value = JSON.parse(saved);
      return {
        sessions: Number(value.sessions) || 0,
        correct: Number(value.correct) || 0,
        total: Number(value.total) || 0,
        best: Number.isFinite(value.best) ? value.best : null,
        subject: value.subject && typeof value.subject === 'object' ? value.subject : {},
        history: Array.isArray(value.history) ? value.history.slice(0,12) : []
      };
    } catch (_) {
      return {sessions:0, correct:0, total:0, best:null, subject:{}, history:[]};
    }
  }
  let progress = safeRead();

  function safeWrite() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(progress)); } catch (_) { /* device storage can be full */ }
  }
  function shuffle(items) {
    const arr = items.slice();
    for (let i=arr.length-1;i>0;i--) {
      const j = Math.floor(Math.random()*(i+1));
      [arr[i],arr[j]] = [arr[j],arr[i]];
    }
    return arr;
  }
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(el => el.classList.toggle('active', el.id === id));
    window.scrollTo(0,0);
  }
  function applyTheme(theme, persist=true) {
    const valid = ['light','blue','graphite','amoled'].includes(theme) ? theme : 'blue';
    document.documentElement.dataset.theme = valid;
    document.querySelectorAll('[data-theme-choice]').forEach(btn => {
      const active = btn.dataset.themeChoice === valid;
      btn.classList.toggle('selected', active);
      btn.setAttribute('aria-pressed', String(active));
    });
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.content = valid === 'light' ? '#f3f5f8' : valid === 'amoled' ? '#000000' : valid === 'graphite' ? '#17191d' : '#111827';
    try { if (window.QuizMixNative && window.QuizMixNative.setThemeColor) window.QuizMixNative.setThemeColor(valid); } catch (_) {}
    if (persist) { try { localStorage.setItem(THEME_KEY, valid); } catch (_) {} }
  }
  function setHolidayMode(value, persist=true) {
    holidaysMode = !!value;
    $('holiday-toggle').classList.toggle('selected', holidaysMode);
    $('holiday-toggle').textContent = `Каникулы: ${holidaysMode ? 'вкл.' : 'выкл.'}`;
    $('holiday-toggle').setAttribute('aria-pressed', String(holidaysMode));
    if (persist) { try { localStorage.setItem(HOLIDAY_KEY, holidaysMode ? '1' : '0'); } catch (_) {} }
    updateSchoolClock();
  }
  const LESSONS = [
    ['08:00','08:40'],['08:55','09:35'],['09:50','10:30'],['10:45','11:25'],
    ['11:40','12:20'],['12:35','13:15'],['13:30','14:10']
  ];
  function minutesOf(value) { const [h,m]=value.split(':').map(Number); return h*60+m; }
  function clockText(seconds) {
    const h=Math.floor(seconds/3600), m=Math.floor((seconds%3600)/60), s=seconds%60;
    return h ? `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}` : `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }
  function updateSchoolClock() {
    const box=$('school-clock');
    if (!box) return;
    const now=new Date();
    const day=now.getDay();
    if (holidaysMode || day===0 || day===6) { box.classList.add('hidden'); return; }
    const current=now.getHours()*60+now.getMinutes();
    const seconds=now.getSeconds();
    for (let i=0;i<LESSONS.length;i++) {
      const [start,end]=LESSONS[i], a=minutesOf(start), b=minutesOf(end);
      if (current>=a && current<b) {
        $('school-clock-label').textContent=`УРОК ${i+1} · ДО КОНЦА`;
        $('school-clock-time').textContent=clockText((b-current-1)*60+(60-seconds));
        box.classList.remove('hidden'); return;
      }
      if (current<a) {
        const previous=i ? minutesOf(LESSONS[i-1][1]) : null;
        $('school-clock-label').textContent=previous===null ? 'ДО НАЧАЛА УРОКОВ' : `ПЕРЕМЕНА · ДО УРОКА ${i+1}`;
        $('school-clock-time').textContent=clockText((a-current-1)*60+(60-seconds));
        box.classList.remove('hidden'); return;
      }
    }
    box.classList.add('hidden');
  }

  function filteredBank() { return BANK.filter(q => selectedSubjects.has(q.subject)); }
  function updateSubjectUI() {
    document.querySelectorAll('[data-subject-choice]').forEach(btn => {
      const active = selectedSubjects.has(btn.dataset.subjectChoice);
      btn.classList.toggle('selected', active);
      btn.setAttribute('aria-pressed', String(active));
    });
    const available = filteredBank().length;
    $('available-count').textContent = available;
    $('selected-subjects').textContent = Object.keys(SUBJECTS).filter(k => selectedSubjects.has(k)).map(k => SUBJECTS[k].short).join(' + ') || 'Ничего не выбрано';
    $('start-button').disabled = available === 0;
    $('selection-note').textContent = available ? `В выбранных предметах доступно ${available} вопросов. Экзамен будет содержать до ${Math.min(selectedCount,available)} уникальных вопросов.` : 'Выбери хотя бы один предмет.';
  }
  function renderGlobalSubjectStats() {
    const container = $('global-subject-stats');
    if (!container) return;
    container.innerHTML = '';
    let visible = 0;
    Object.keys(SUBJECTS).forEach(k => {
      const item = progress.subject[k] || {total:0,correct:0};
      if (!item.total) return;
      visible++;
      const pct = Math.round(item.correct / item.total * 100);
      const row = document.createElement('div');
      row.className = 'breakdown-row';
      row.innerHTML = '<div class="breakdown-name"></div><div class="breakdown-bar"><div class="breakdown-fill"></div></div><div class="breakdown-score"></div>';
      row.querySelector('.breakdown-name').textContent = SUBJECTS[k].short;
      row.querySelector('.breakdown-fill').style.width = `${pct}%`;
      row.querySelector('.breakdown-fill').style.background = SUBJECTS[k].color;
      row.querySelector('.breakdown-score').textContent = `${pct}%`;
      const count = document.createElement('div');
      count.className = 'global-subject-count';
      count.textContent = `${item.correct} из ${item.total} верно с первого раза`;
      container.append(row, count);
    });
    if (!visible) container.innerHTML = '<div class="history-empty">Статистика появится после первого экзамена.</div>';
  }
  function updateHomeStats() {
    $('bank-count').textContent = BANK.length;
    $('stat-sessions').textContent = progress.sessions;
    $('stat-correct').textContent = progress.total ? `${progress.correct}` : '0';
    $('stat-best').textContent = progress.best === null ? '—' : `${progress.best}%`;
    $('history-count').textContent = progress.history.length;
    renderHistoryList();
    renderGlobalSubjectStats();
    updateSubjectUI();
  }
  function randomTicket() { return String(1 + Math.floor(Math.random()*40)).padStart(3,'0'); }
  function hintFor(q) {
    if (q.hint) return q.hint;
    if (RUS_HINTS[q.id]) return RUS_HINTS[q.id];
    const topic = String(q.topic || '').toLowerCase();
    if (q.subject === 'pdd') {
      if (/светофор|сигнал/.test(topic)) return 'Сначала определи, кому адресован сигнал и что именно он разрешает или запрещает. Учитывай дополнительные секции и мигающий режим.';
      if (/знак/.test(topic)) return 'Вспомни форму, цвет и назначение знака. Не путай предупреждающие, запрещающие и предписывающие знаки.';
      if (/перекрёст/.test(topic)) return 'Определи, регулируется ли перекрёсток, равнозначны ли дороги и кто имеет преимущество по знакам или общему правилу.';
      if (/пешеход/.test(topic)) return 'Учитывай тип перехода, направление движения автомобиля и положение пешехода. «Уступить» не всегда означает просто снизить скорость.';
      if (/манёвр|обгон|перестро/.test(topic)) return 'Перед манёвром проверь безопасность, сигналы и преимущество тех, кто уже движется по выбранной полосе.';
      if (/скорост/.test(topic)) return 'Сопоставь установленное ограничение с дорожными и погодными условиями: разрешённый максимум не всегда является безопасной скоростью.';
      if (/переезд/.test(topic)) return 'На железнодорожном переезде решающими являются запрещающий сигнал, положение шлагбаума и отсутствие затора за переездом.';
      return 'Определи, какое общее правило ПДД регулирует эту ситуацию, и проверь, нет ли специального условия или исключения.';
    }
    if (q.subject === 'chem') {
      if (/элемент|таблиц/.test(topic)) return 'Вспомни положение элемента в периодической системе и закономерность, связанную с его группой или периодом.';
      if (/реакц|окисл|восстанов/.test(topic)) return 'Определи, какие частицы изменяют состав или степень окисления, и проверь сохранение числа атомов.';
      if (/кислот|основан|соль/.test(topic)) return 'Сначала классифицируй вещество по составу и функциональным группам, затем проверь характерные свойства класса.';
      if (/раствор|концентрац/.test(topic)) return 'Раздели массу растворённого вещества и массу всего раствора; не смешивай долю с процентами.';
      return 'Вспомни основное определение по теме и проверь, согласуется ли с ним формула или свойство вещества.';
    }
    if (q.subject === 'bio') {
      if (/генет|наслед|днк|рнк/.test(topic)) return 'Раздели понятия генотипа, фенотипа и наследуемого признака; внимательно следи за тем, что именно спрашивается.';
      if (/клетк|органоид/.test(topic)) return 'Соотнеси функцию с органоидом: синтез, транспорт, энергетический обмен и хранение информации выполняют разные структуры.';
      if (/эколог|экосистем|пищев/.test(topic)) return 'Проверь, к какому уровню организации относится объект и как передаются вещество и энергия.';
      if (/орган|систем|кров|дых|пищевар/.test(topic)) return 'Свяжи орган с его основной функцией и направлением процесса, а не только с названием системы.';
      return 'Вспомни биологическую функцию или процесс, о котором спрашивается, и отличи его от соседних понятий.';
    }
    return `Вспомни ключевое правило по теме «${q.topic}» и проверь каждый вариант на соответствие ему.`;
  }
  function startExam(count) {
    const available = filteredBank();
    const questions = shuffle(available).slice(0, Math.min(count, available.length));
    if (!questions.length) return;
    session = {
      queue: questions.map(q => ({q,retry:false})), pointer:0, target:questions.length,
      firstDone:0, attempts:0, firstCorrect:0, recovered:0, unresolved:[], originallyWrong:[],
      bySubject:{}, active:null, answered:false, ticket:randomTicket(), reviewLog:[], isReview:false
    };
    Object.keys(SUBJECTS).forEach(k => session.bySubject[k] = {total:0,correct:0});
    $('ticket-number').textContent = session.ticket;
    $('pass-label').textContent = 'ПЕРВЫЙ ПРОХОД';
    showScreen('exam-screen');
    renderQuestion();
  }
  function currentItem() { return session && session.queue[session.pointer]; }
  function renderQuestion() {
    const item = currentItem();
    if (!item) { finishExam(); return; }
    const q = item.q;
    const meta = SUBJECTS[q.subject] || SUBJECTS.chem;
    session.active = {item, options:shuffle(q.options)};
    session.answered = false;
    $('question-counter').textContent = `${String(Math.min(session.firstDone + (item.retry?0:1), session.target)).padStart(2,'0')} / ${session.target}`;
    $('first-pass-count').textContent = `Первый проход: ${session.firstDone} / ${session.target}`;
    $('attempt-count').textContent = `Ответов дано: ${session.attempts}`;
    $('progress-bar').style.width = `${Math.round((session.firstDone/session.target)*100)}%`;
    $('subject-chip').className = `subject-chip ${meta.cls}`;
    $('subject-chip').textContent = `${meta.icon} ${meta.name}`;
    $('topic-label').textContent = q.topic;
    $('question-text').textContent = q.question;
    const pddArt = $('pdd-illustration');
    if (q.subject === 'pdd') { pddArt.innerHTML = window.quizMixPddIllustration ? window.quizMixPddIllustration(q.id) : ''; pddArt.classList.remove('hidden'); }
    else { pddArt.innerHTML = ''; pddArt.classList.add('hidden'); }
    $('pass-label').textContent = item.retry ? 'ВОЗВРАТ ОШИБКИ' : 'ПЕРВЫЙ ПРОХОД';
    $('feedback').className = 'feedback hidden';
    $('feedback').innerHTML = '';
    $('hint-panel').classList.add('hidden');
    $('hint-panel').textContent = '';
    $('hint-button').textContent = 'ПОДСКАЗКА';
    $('hint-button').classList.remove('used');
    $('next-button').classList.add('hidden');
    $('next-button').textContent = 'СЛЕДУЮЩИЙ ВОПРОС →';
    const answers = $('answers-list');
    answers.innerHTML = '';
    session.active.options.forEach((option, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'answer-option';
      button.innerHTML = `<span class="answer-letter">${String.fromCharCode(65+index)}</span><span></span>`;
      button.querySelector('span:last-child').textContent = option;
      button.addEventListener('click', () => chooseAnswer(option, button));
      answers.appendChild(button);
    });
  }
  function showHint() {
    const item = currentItem();
    if (!item || !session) return;
    $('hint-panel').textContent = hintFor(item.q);
    $('hint-panel').classList.remove('hidden');
    $('hint-button').textContent = 'СКРЫТЬ ПОДСКАЗКУ';
    $('hint-button').classList.add('used');
  }
  function chooseAnswer(selected) {
    if (session.answered) return;
    session.answered = true;
    const {item} = session.active;
    const q = item.q;
    const isCorrect = selected === q.answer;
    session.attempts++;
    session.reviewLog.push({questionId:q.id,subject:q.subject,topic:q.topic,question:q.question,options:q.options,selected,answer:q.answer,correct:isCorrect,explanation:q.explanation,hint:hintFor(q),retry:item.retry});
    if (!item.retry) {
      session.firstDone++;
      session.bySubject[q.subject].total++;
      if (isCorrect) {
        session.firstCorrect++;
        session.bySubject[q.subject].correct++;
      } else {
        session.originallyWrong.push(q);
        const remaining = session.queue.length - session.pointer - 1;
        const offset = 1 + Math.floor(Math.random() * Math.max(1, Math.min(5, remaining + 1)));
        const insertAt = Math.min(session.queue.length, session.pointer + offset);
        session.queue.splice(insertAt, 0, {q,retry:true});
      }
    } else {
      if (isCorrect) session.recovered++;
      else session.unresolved.push(q);
    }
    document.querySelectorAll('.answer-option').forEach(btn => {
      const text = btn.querySelector('span:last-child').textContent;
      btn.disabled = true;
      if (text === q.answer) btn.classList.add('correct');
      else if (text === selected && !isCorrect) btn.classList.add('wrong');
      else btn.classList.add('dimmed');
    });
    const feedback = $('feedback');
    feedback.className = `feedback ${isCorrect ? 'good' : 'bad'}`;
    const title = isCorrect ? (item.retry ? 'Верно. Ошибка исправлена.' : 'Правильно!') : (item.retry ? 'Пока не получилось.' : 'Не совсем. Этот вопрос вернётся позже.');
    feedback.innerHTML = `<div class="feedback-title"></div><div class="feedback-answer"></div><div class="feedback-explain"></div>`;
    feedback.querySelector('.feedback-title').textContent = title;
    feedback.querySelector('.feedback-answer').textContent = `Правильный ответ: ${q.answer}`;
    feedback.querySelector('.feedback-explain').textContent = q.explanation;
    $('next-button').classList.remove('hidden');
    $('next-button').textContent = session.pointer >= session.queue.length - 1 ? 'ЗАВЕРШИТЬ ЭКЗАМЕН' : 'СЛЕДУЮЩИЙ ВОПРОС →';
    $('first-pass-count').textContent = `Первый проход: ${session.firstDone} / ${session.target}`;
    $('attempt-count').textContent = `Ответов дано: ${session.attempts}`;
    $('progress-bar').style.width = `${Math.round((session.firstDone/session.target)*100)}%`;
    if (navigator.vibrate) navigator.vibrate(isCorrect ? 18 : [20,35,20]);
  }
  function nextQuestion() {
    session.pointer++;
    if (session.pointer >= session.queue.length) finishExam();
    else renderQuestion();
  }
  function formatDate(value) {
    try { return new Intl.DateTimeFormat('ru-RU',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(new Date(value)); }
    catch (_) { return 'Дата неизвестна'; }
  }
  function compactReviewEntries(log) {
    const grouped = new Map();
    log.forEach(a => {
      if (!grouped.has(a.questionId)) grouped.set(a.questionId, {
        questionId:a.questionId,subject:a.subject,topic:a.topic,question:a.question,
        options:a.options,answer:a.answer,explanation:a.explanation,hint:a.hint,attempts:[]
      });
      grouped.get(a.questionId).attempts.push({selected:a.selected,correct:a.correct,retry:a.retry});
    });
    return Array.from(grouped.values());
  }
  function renderSubjectBreakdown(data) {
    const breakdown = $('subject-breakdown');
    breakdown.innerHTML = '';
    Object.keys(SUBJECTS).forEach(k => {
      const item = data[k] || {total:0,correct:0};
      if (!item.total) return;
      const meta = SUBJECTS[k];
      const pct = Math.round(item.correct/item.total*100);
      const row = document.createElement('div');
      row.className = 'breakdown-row';
      row.innerHTML = `<div class="breakdown-name"></div><div class="breakdown-bar"><div class="breakdown-fill" style="width:${pct}%;background:${meta.color}"></div></div><div class="breakdown-score">${pct}%</div>`;
      row.querySelector('.breakdown-name').textContent = meta.name;
      breakdown.appendChild(row);
    });
    if (!breakdown.children.length) breakdown.textContent = 'Нет данных по предметам.';
  }
  function finishExam() {
    const s = session;
    const percent = s.target ? Math.round((s.firstCorrect/s.target)*100) : 0;
    const subjectNames = Object.keys(SUBJECTS).filter(k => s.bySubject[k].total).map(k => SUBJECTS[k].short);
    const historyItem = {
      id:`${Date.now()}-${Math.floor(Math.random()*10000)}`, date:new Date().toISOString(), total:s.target,
      correct:s.firstCorrect, recovered:s.recovered, unresolved:s.unresolved.length, attempts:s.attempts,
      percent, subjects:subjectNames, bySubject:s.bySubject, entries:compactReviewEntries(s.reviewLog)
    };
    progress.sessions++;
    progress.correct += s.firstCorrect;
    progress.total += s.target;
    progress.best = progress.best === null ? percent : Math.max(progress.best, percent);
    Object.keys(s.bySubject).forEach(k => {
      const prev = progress.subject[k] || {total:0,correct:0};
      progress.subject[k] = {total:prev.total+s.bySubject[k].total,correct:prev.correct+s.bySubject[k].correct};
    });
    progress.history.unshift(historyItem);
    progress.history = progress.history.slice(0,12);
    safeWrite();
    $('result-percent').textContent = `${percent}%`;
    $('result-title').textContent = percent >= 85 ? 'Отличный результат' : percent >= 65 ? 'Хорошая работа' : 'Есть что повторить';
    $('result-subtitle').textContent = `Первый проход: ${s.firstCorrect} правильных из ${s.target}. Всего ответов с повторениями: ${s.attempts}.`;
    $('result-first').textContent = `${s.firstCorrect} / ${s.target}`;
    $('result-recovered').textContent = s.recovered;
    $('result-unresolved').textContent = s.unresolved.length;
    $('result-attempts').textContent = s.attempts;
    renderSubjectBreakdown(s.bySubject);
    const mistakesPanel = $('mistakes-panel');
    const reviewQuestions = [];
    const seen = new Set();
    s.originallyWrong.forEach(q => { if (!seen.has(q.id)) { seen.add(q.id); reviewQuestions.push(q); } });
    if (reviewQuestions.length) {
      mistakesPanel.classList.remove('hidden');
      $('mistakes-list').innerHTML = '';
      reviewQuestions.slice(0,8).forEach(q => {
        const div = document.createElement('div');
        div.className = 'mistake-item';
        const strong = document.createElement('strong'); strong.textContent = q.question;
        const span = document.createElement('span'); span.textContent = `${SUBJECTS[q.subject].name} · ${q.topic}`;
        div.append(strong,span); $('mistakes-list').appendChild(div);
      });
      $('review-button').onclick = () => openReview(historyItem, 'mistakes', 'result-screen');
      $('review-button').textContent = `РАЗОБРАТЬ ОШИБКИ (${reviewQuestions.length})`;
    } else {
      mistakesPanel.classList.add('hidden');
    }
    $('result-all-review').onclick = () => openReview(historyItem, 'all', 'result-screen');
    updateHomeStats();
    showScreen('result-screen');
  }
  function buildReviewCard(group, index) {
    const meta = SUBJECTS[group.subject] || SUBJECTS.chem;
    const details = document.createElement('details');
    const finalCorrect = group.attempts[group.attempts.length - 1].correct;
    const wasRecovered = !group.attempts[0].correct && finalCorrect;
    details.className = `review-question ${finalCorrect ? 'review-ok' : 'review-error'}`;
    const summary = document.createElement('summary');
    const badge = wasRecovered ? 'Исправлено' : finalCorrect ? 'Верно' : 'Ошибка';
    summary.innerHTML = `<span class="review-index">${index+1}</span><span class="review-summary-copy"><strong></strong><small></small></span><span class="review-status"></span>`;
    summary.querySelector('strong').textContent = group.question;
    summary.querySelector('small').textContent = `${meta.name} · ${group.topic}`;
    summary.querySelector('.review-status').textContent = badge;
    details.appendChild(summary);
    const body = document.createElement('div'); body.className = 'review-body';
    group.attempts.forEach((a,i) => {
      const attempt = document.createElement('div'); attempt.className = 'review-attempt';
      const cap = document.createElement('div'); cap.className = 'review-attempt-cap'; cap.textContent = `${a.retry ? 'Повторная попытка' : 'Первый ответ'}${group.attempts.length>1 ? ` · ${i+1}` : ''}`;
      const your = document.createElement('p'); your.className = 'review-user-answer';
      your.textContent = `Твой ответ: ${a.selected} — ${a.correct ? 'верно' : 'неверно'}`;
      if (!a.correct) your.classList.add('wrong-text');
      const right = document.createElement('p'); right.className = 'review-correct-answer'; right.textContent = `Правильный ответ: ${group.answer}`;
      attempt.append(cap,your,right);
      if (i===group.attempts.length-1 || !a.correct) {
        const explain = document.createElement('p'); explain.className='review-explanation'; explain.textContent = `Объяснение: ${group.explanation}`;
        const hint = document.createElement('p'); hint.className='review-hint'; hint.textContent = `Подсказка: ${group.hint}`;
        attempt.append(explain,hint);
      }
      body.appendChild(attempt);
    });
    details.appendChild(body);
    return details;
  }
  function openReview(source, filter='all', returnScreen='home-screen') {
    reviewSource = source;
    reviewFilter = filter;
    reviewReturnScreen = returnScreen;
    $('review-title').textContent = source.subjects ? source.subjects.join(' + ') : 'Разбор экзамена';
    $('review-subtitle').textContent = `${formatDate(source.date)} · ${source.correct} из ${source.total} · ${source.percent}%`;
    $('review-filter-all').classList.toggle('selected',filter==='all');
    $('review-filter-errors').classList.toggle('selected',filter==='mistakes');
    renderReviewList();
    showScreen('review-screen');
  }
  function renderReviewList() {
    const container = $('review-list');
    container.innerHTML = '';
    if (!reviewSource || !Array.isArray(reviewSource.entries)) return;
    let values = reviewSource.entries.slice();
    if (reviewFilter === 'mistakes') values = values.filter(g => g.attempts.some(a => !a.correct));
    $('review-question-count').textContent = `${values.length} вопросов`;
    if (!values.length) { container.textContent = 'В этой категории вопросов нет.'; return; }
    values.forEach((group,index) => container.appendChild(buildReviewCard(group,index)));
  }
  function renderHistoryList() {
    const list = $('history-list');
    list.innerHTML = '';
    const history = progress.history || [];
    $('history-empty').classList.toggle('hidden',history.length>0);
    history.forEach(item => {
      const button = document.createElement('button');
      button.type='button'; button.className='history-item';
      const left=document.createElement('span');left.className='history-item-main';
      const strong=document.createElement('strong');strong.textContent=`${item.subjects.join(' + ')} · ${item.total} вопросов`;
      const small=document.createElement('small');small.textContent=formatDate(item.date);
      left.append(strong,small);
      const score=document.createElement('span');score.className='history-score';score.textContent=`${item.percent}%`;
      button.append(left,score);
      button.addEventListener('click',()=>openReview(item,'all','home-screen'));
      list.appendChild(button);
    });
  }
  function exitExam() {
    const ok = window.confirm('Завершить экзамен сейчас? Текущий результат не будет сохранён.');
    if (ok) { session = null; showScreen('home-screen'); }
  }

  document.querySelectorAll('.mode-card').forEach(button => {
    button.addEventListener('click', () => {
      selectedCount = Number(button.dataset.count) || 25;
      document.querySelectorAll('.mode-card').forEach(el => el.classList.toggle('selected', el===button));
      updateSubjectUI();
    });
  });
  document.querySelectorAll('[data-subject-choice]').forEach(button => {
    button.addEventListener('click', () => {
      const key=button.dataset.subjectChoice;
      if (selectedSubjects.has(key)) { if (selectedSubjects.size>1) selectedSubjects.delete(key); }
      else selectedSubjects.add(key);
      updateSubjectUI();
    });
  });
  $('select-all-subjects').addEventListener('click',()=>{selectedSubjects=new Set(Object.keys(SUBJECTS));updateSubjectUI();});
  document.querySelectorAll('[data-theme-choice]').forEach(btn=>btn.addEventListener('click',()=>applyTheme(btn.dataset.themeChoice)));
  $('start-button').addEventListener('click', () => startExam(selectedCount));
  $('holiday-toggle').addEventListener('click',()=>setHolidayMode(!holidaysMode));
  $('hint-button').addEventListener('click',()=>{
    if ($('hint-panel').classList.contains('hidden')) showHint();
    else { $('hint-panel').classList.add('hidden'); $('hint-button').textContent='ПОДСКАЗКА'; $('hint-button').classList.remove('used'); }
  });
  $('next-button').addEventListener('click', nextQuestion);
  $('exit-exam').addEventListener('click', exitExam);
  $('home-button').addEventListener('click', () => { session=null; updateHomeStats(); showScreen('home-screen'); });
  $('review-back').addEventListener('click',()=>showScreen(reviewReturnScreen));
  $('review-filter-all').addEventListener('click',()=>{reviewFilter='all';$('review-filter-all').classList.add('selected');$('review-filter-errors').classList.remove('selected');renderReviewList();});
  $('review-filter-errors').addEventListener('click',()=>{reviewFilter='mistakes';$('review-filter-errors').classList.add('selected');$('review-filter-all').classList.remove('selected');renderReviewList();});
  window.quizMixAndroidBack = () => {
    const active = document.querySelector('.screen.active');
    if (active && active.id === 'exam-screen') { exitExam(); return true; }
    if (active && active.id === 'review-screen') { showScreen(reviewReturnScreen); return true; }
    if (active && active.id === 'result-screen') { session=null; updateHomeStats(); showScreen('home-screen'); return true; }
    return false;
  };
  try { applyTheme(localStorage.getItem(THEME_KEY) || 'blue',false); } catch (_) { applyTheme('blue',false); }
  try { setHolidayMode(localStorage.getItem(HOLIDAY_KEY)==='1',false); } catch (_) { setHolidayMode(false,false); }
  updateHomeStats();
  updateSchoolClock();
  window.setInterval(updateSchoolClock,1000);
})();
