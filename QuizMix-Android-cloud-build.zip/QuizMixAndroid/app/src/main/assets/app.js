(() => {
  'use strict';
  const BANK = Array.isArray(window.QUIZMIX_BANK) ? window.QUIZMIX_BANK : [];
  const SUBJECTS = {
    chem: {name:'Химия', icon:'⚗', cls:'chem-tag', color:'#c6a2ff'},
    bio: {name:'Биология', icon:'✳', cls:'bio-tag', color:'#7fe0b3'},
    rus: {name:'Русский язык', icon:'Аа', cls:'rus-tag', color:'#ffd27a'},
    pdd: {name:'ПДД', icon:'▰', cls:'pdd-tag', color:'#86baff'}
  };
  const STORAGE_KEY = 'quizmix_progress_v1';
  const $ = (id) => document.getElementById(id);
  let selectedCount = 25;
  let session = null;

  function safeRead() {
    try {
      const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      return {
        sessions: Number(value.sessions) || 0,
        correct: Number(value.correct) || 0,
        total: Number(value.total) || 0,
        best: Number.isFinite(value.best) ? value.best : null,
        subject: value.subject || {}
      };
    } catch (_) {
      return {sessions:0, correct:0, total:0, best:null, subject:{}};
    }
  }
  let progress = safeRead();

  function safeWrite() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(progress)); } catch (_) { /* storage may be unavailable */ }
  }
  function shuffle(items) {
    const arr = items.slice();
    for (let i=arr.length-1;i>0;i--) {
      const j = Math.floor(Math.random()*(i+1));
      [arr[i],arr[j]] = [arr[j],arr[i]];
    }
    return arr;
  }
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(el => el.classList.toggle('active', el.id === id));
    window.scrollTo(0,0);
  }
  function updateHomeStats() {
    $('bank-count').textContent = BANK.length;
    $('stat-sessions').textContent = progress.sessions;
    $('stat-correct').textContent = progress.total ? `${progress.correct}` : '0';
    $('stat-best').textContent = progress.best === null ? '—' : `${progress.best}%`;
  }
  function randomTicket() { return String(1 + Math.floor(Math.random()*40)).padStart(3,'0'); }
  function pickQuestions(count) {
    return shuffle(BANK).slice(0, Math.min(count, BANK.length)).map(q => ({q, retry:false}));
  }
  function startExam(count, fixedQuestions=null) {
    const queue = fixedQuestions || pickQuestions(count);
    if (!queue.length) return;
    session = {
      queue, pointer:0, target:queue.length, firstDone:0, attempts:0,
      firstCorrect:0, recovered:0, unresolved:[], originallyWrong:[],
      bySubject: {}, active:null, answered:false, ticket:randomTicket(),
      seen:new Set(), isReview:!!fixedQuestions
    };
    Object.keys(SUBJECTS).forEach(k => session.bySubject[k] = {total:0,correct:0});
    queue.forEach(item => session.seen.add(item.q.id));
    $('ticket-number').textContent = session.ticket;
    $('pass-label').textContent = fixedQuestions ? 'ПОВТОРЕНИЕ ОШИБОК' : 'ПЕРВЫЙ ПРОХОД';
    showScreen('exam-screen');
    renderQuestion();
  }
  function currentItem() { return session && session.queue[session.pointer]; }
  function renderQuestion() {
    const item = currentItem();
    if (!item) { finishExam(); return; }
    const q = item.q;
    const meta = SUBJECTS[q.subject] || SUBJECTS.chem;
    session.active = {item, options:shuffle(q.options)};
    session.answered = false;
    $('question-counter').textContent = `${String(Math.min(session.firstDone + (item.retry?0:1), session.target)).padStart(2,'0')} / ${session.target}`;
    $('first-pass-count').textContent = `Первый проход: ${session.firstDone} / ${session.target}`;
    $('attempt-count').textContent = `Ответов дано: ${session.attempts}`;
    $('progress-bar').style.width = `${Math.round((session.firstDone/session.target)*100)}%`;
    $('subject-chip').className = `subject-chip ${meta.cls}`;
    $('subject-chip').textContent = `${meta.icon} ${meta.name}`;
    $('topic-label').textContent = q.topic;
    $('question-text').textContent = q.question;
    const pddArt = $('pdd-illustration');
    if (q.subject === 'pdd') { pddArt.innerHTML = window.quizMixPddIllustration ? window.quizMixPddIllustration(q.id) : ''; pddArt.classList.remove('hidden'); }
    else { pddArt.innerHTML = ''; pddArt.classList.add('hidden'); }
    $('pass-label').textContent = item.retry ? 'ВОЗВРАТ ОШИБКИ' : (session.isReview ? 'ПОВТОРЕНИЕ ОШИБОК' : 'ПЕРВЫЙ ПРОХОД');
    $('feedback').className = 'feedback hidden';
    $('feedback').innerHTML = '';
    $('next-button').classList.add('hidden');
    const answers = $('answers-list');
    answers.innerHTML = '';
    session.active.options.forEach((option, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'answer-option';
      button.innerHTML = `<span class="answer-letter">${String.fromCharCode(65+index)}</span><span></span>`;
      button.querySelector('span:last-child').textContent = option;
      button.addEventListener('click', () => chooseAnswer(option, button));
      answers.appendChild(button);
    });
  }
  function chooseAnswer(selected, selectedButton) {
    if (session.answered) return;
    session.answered = true;
    const {item, options} = session.active;
    const q = item.q;
    const isCorrect = selected === q.answer;
    session.attempts++;
    if (!item.retry) {
      session.firstDone++;
      session.bySubject[q.subject].total++;
      if (isCorrect) {
        session.firstCorrect++;
        session.bySubject[q.subject].correct++;
      } else {
        session.originallyWrong.push(q);
        // Insert the retry a few questions later, among the remaining mixed subjects.
        const remaining = session.queue.length - session.pointer - 1;
        const offset = 1 + Math.floor(Math.random() * Math.max(1, Math.min(5, remaining + 1)));
        const insertAt = Math.min(session.queue.length, session.pointer + offset);
        session.queue.splice(insertAt, 0, {q, retry:true});
      }
    } else {
      if (isCorrect) session.recovered++;
      else session.unresolved.push(q);
    }
    document.querySelectorAll('.answer-option').forEach(btn => {
      const text = btn.querySelector('span:last-child').textContent;
      btn.disabled = true;
      if (text === q.answer) btn.classList.add('correct');
      else if (text === selected && !isCorrect) btn.classList.add('wrong');
      else btn.classList.add('dimmed');
    });
    const feedback = $('feedback');
    feedback.className = `feedback ${isCorrect ? 'good' : 'bad'}`;
    const title = isCorrect ? (item.retry ? 'Верно. Ошибка исправлена.' : 'Правильно!') : (item.retry ? 'Пока не получилось.' : 'Не совсем. Этот вопрос вернётся позже.');
    feedback.innerHTML = `<div class="feedback-title"></div><div class="feedback-answer"></div><div class="feedback-explain"></div>`;
    feedback.querySelector('.feedback-title').textContent = title;
    feedback.querySelector('.feedback-answer').textContent = `Правильный ответ: ${q.answer}`;
    feedback.querySelector('.feedback-explain').textContent = q.explanation;
    $('next-button').classList.remove('hidden');
    $('next-button').textContent = session.pointer >= session.queue.length - 1 ? 'ЗАВЕРШИТЬ ЭКЗАМЕН' : 'СЛЕДУЮЩИЙ ВОПРОС →';
    $('first-pass-count').textContent = `Первый проход: ${session.firstDone} / ${session.target}`;
    $('attempt-count').textContent = `Ответов дано: ${session.attempts}`;
    $('progress-bar').style.width = `${Math.round((session.firstDone/session.target)*100)}%`;
    if (navigator.vibrate) navigator.vibrate(isCorrect ? 18 : [20,35,20]);
  }
  function nextQuestion() {
    session.pointer++;
    if (session.pointer >= session.queue.length) finishExam();
    else renderQuestion();
  }
  function finishExam() {
    const s = session;
    const percent = s.target ? Math.round((s.firstCorrect/s.target)*100) : 0;
    const summary = {
      total:s.target, correct:s.firstCorrect, recovered:s.recovered,
      unresolved:s.unresolved.length, attempts:s.attempts, percent
    };
    progress.sessions++;
    progress.correct += s.firstCorrect;
    progress.total += s.target;
    progress.best = progress.best === null ? percent : Math.max(progress.best, percent);
    Object.keys(s.bySubject).forEach(k => {
      const prev = progress.subject[k] || {total:0,correct:0};
      progress.subject[k] = {total:prev.total+s.bySubject[k].total, correct:prev.correct+s.bySubject[k].correct};
    });
    safeWrite();
    $('result-percent').textContent = `${percent}%`;
    $('result-title').textContent = percent >= 85 ? 'Отличный результат' : percent >= 65 ? 'Хорошая работа' : 'Есть что повторить';
    $('result-subtitle').textContent = `Первый проход: ${s.firstCorrect} правильных из ${s.target}. Всего ответов с повторениями: ${s.attempts}.`;
    $('result-first').textContent = `${s.firstCorrect} / ${s.target}`;
    $('result-recovered').textContent = s.recovered;
    $('result-unresolved').textContent = s.unresolved.length;
    $('result-attempts').textContent = s.attempts;
    const breakdown = $('subject-breakdown');
    breakdown.innerHTML = '';
    Object.keys(SUBJECTS).forEach(k => {
      const data = s.bySubject[k];
      const meta = SUBJECTS[k];
      const pct = data.total ? Math.round(data.correct/data.total*100) : 0;
      const row = document.createElement('div');
      row.className = 'breakdown-row';
      row.innerHTML = `<div class="breakdown-name"></div><div class="breakdown-bar"><div class="breakdown-fill" style="width:${pct}%;background:${meta.color}"></div></div><div class="breakdown-score">${data.total ? `${pct}%` : '—'}</div>`;
      row.querySelector('.breakdown-name').textContent = meta.name;
      breakdown.appendChild(row);
    });
    const mistakesPanel = $('mistakes-panel');
    const reviewQuestions = [];
    const seen = new Set();
    s.originallyWrong.forEach(q => { if (!seen.has(q.id)) { seen.add(q.id); reviewQuestions.push(q); } });
    if (reviewQuestions.length) {
      mistakesPanel.classList.remove('hidden');
      $('mistakes-list').innerHTML = '';
      reviewQuestions.slice(0,8).forEach(q => {
        const div = document.createElement('div');
        div.className = 'mistake-item';
        const strong = document.createElement('strong'); strong.textContent = q.question;
        const span = document.createElement('span'); span.textContent = `${SUBJECTS[q.subject].name} · ${q.topic}`;
        div.append(strong,span); $('mistakes-list').appendChild(div);
      });
      $('review-button').onclick = () => startExam(reviewQuestions.length, shuffle(reviewQuestions).map(q => ({q,retry:false})));
      $('review-button').textContent = `ПОВТОРИТЬ ОШИБКИ (${reviewQuestions.length})`;
    } else {
      mistakesPanel.classList.add('hidden');
    }
    updateHomeStats();
    showScreen('result-screen');
  }
  function exitExam() {
    const ok = window.confirm('Завершить экзамен сейчас? Текущий результат не будет сохранён.');
    if (ok) { session = null; showScreen('home-screen'); }
  }

  document.querySelectorAll('.mode-card').forEach(button => {
    button.addEventListener('click', () => {
      selectedCount = Number(button.dataset.count) || 25;
      document.querySelectorAll('.mode-card').forEach(el => el.classList.toggle('selected', el===button));
    });
  });
  $('start-button').addEventListener('click', () => startExam(selectedCount));
  $('next-button').addEventListener('click', nextQuestion);
  $('exit-exam').addEventListener('click', exitExam);
  $('home-button').addEventListener('click', () => { session=null; updateHomeStats(); showScreen('home-screen'); });
  window.quizMixAndroidBack = () => {
    const active = document.querySelector('.screen.active');
    if (active && active.id === 'exam-screen') { exitExam(); return true; }
    if (active && active.id === 'result-screen') { session=null; updateHomeStats(); showScreen('home-screen'); return true; }
    return false;
  };
  updateHomeStats();
})();
