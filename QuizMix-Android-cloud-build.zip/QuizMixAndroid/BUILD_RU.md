# Как собрать APK из проекта

Папка содержит исходный Android-проект, но готового APK в архиве нет.

Требуется на компьютере:
- Android Studio;
- JDK 17;
- Android SDK Platform 36;
- Gradle 8.13;
- Android Gradle Plugin 8.13.2 (указан в корневом `build.gradle.kts`).

Действия:
1. Установить Android SDK Platform 36 через SDK Manager.
2. Открыть папку `QuizMixAndroid` в Android Studio.
3. Указать локальный Gradle 8.13 и JDK 17, выполнить Gradle Sync.
4. Выбрать `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.

Debug-сборка обычно появляется в `app/build/outputs/apk/debug/`.
