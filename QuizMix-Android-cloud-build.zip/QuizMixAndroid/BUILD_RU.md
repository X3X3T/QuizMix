# Как собрать APK из проекта

## Через GitHub Actions

1. В репозитории замените старый `QuizMix-Android-cloud-build.zip` новым архивом версии 0.4.
2. Сделайте Commit changes. Существующий workflow запускается автоматически.
3. Откройте вкладку Actions, выберите завершившуюся сборку `Build QuizMix APK`.
4. Внизу страницы скачайте артефакт `QuizMix-debug-APK` и извлеките APK из архива.

Повторно создавать репозиторий или workflow не нужно. Файл workflow в репозитории остаётся прежним.

## Локальная сборка

Требуется Android Studio или Gradle 8.13, JDK 17, Android SDK Platform 36 и Android Gradle Plugin 8.13.2.

Откройте папку `QuizMixAndroid`, выполните Gradle Sync и запустите задачу `app > Tasks > build > assembleDebug`. APK появится в `app/build/outputs/apk/debug/`.

## Подпись APK

Для debug-сборок настроен постоянный тестовый ключ `app/quizmix-debug.keystore`. Не удаляйте его при следующих обновлениях, иначе подпись APK изменится и Android может потребовать удалить прежнюю версию перед установкой. Ключ предназначен только для тестовых сборок.
